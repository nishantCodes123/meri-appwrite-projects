import React, { useEffect } from "react";

import { useNavigate } from "react-router-dom";
import { account } from "../appwrite/config";
function HomePage() {
    const navigate = useNavigate();
    useEffect(() => {
        console.log(account);
    }, []);
    const handleSignUp = () => {
        navigate("/Register");
    };

    const handleLogin = () => {
        navigate("/login");
    };

    return (
        <div className="home-container">
            <h1 className="app-title">Welcome to Todo App</h1>
            <p className="app-description">Organize your tasks and boost your productivity!</p>
            <div className="button-container">
                <button className="home-button" onClick={handleSignUp}>
                    Sign Up
                </button>
                <button className="home-button login-button" onClick={handleLogin}>
                    Login
                </button>
            </div>
        </div>
    );
}

export default HomePage;
