import React, { useEffect, useState } from "react";
import { account, database } from "../appwrite/config";
import { ID, Query } from "appwrite"; 
import { useNavigate } from "react-router-dom";

function Dashboard() {
    const navigate = useNavigate();
    const [email, setEmail] = useState(null);
    const [name, setName] = useState(null);
    const [todo, setTodo] = useState("");
    const [alltodo, setAllTodo] = useState([]);

    
    useEffect(() => {
        isLogin();
    }, []);

    
    const isLogin = async () => {
        try {
            const session = await account.get("current");
            setEmail(session.email);
            setName(session.name);
            console.log(session);

           
            setTimeout(() => {
                viewTodo();
            }, 100); 
        } catch (error) {
            navigate("/Login");
        }
    };

    const logout = async () => {
        try {
            await account.deleteSession("current");
            navigate("/Login");
        } catch (e) {
            console.error("Error during logout:", e);
        }
    };

    const addTodo = async () => {
        if (!todo || todo.trim() === "") {
            alert("Please enter a task before adding.");
            return;
        }
        try {
            const response = await database.createDocument(
                import.meta.env.VITE_APP_DB_ID,
                import.meta.env.VITE_APP_COLLECTION_ID,
                ID.unique(), 
                {
                    email: email,
                    todo: todo,
                }
            );
            console.log("Task added:", response);
            setTodo(""); 
            viewTodo(); 
        } catch (e) {
            console.error("Error adding task:", e);
        }
    };

    const viewTodo = async () => {
        try {
            const show = await database.listDocuments(
                import.meta.env.VITE_APP_DB_ID,
                import.meta.env.VITE_APP_COLLECTION_ID,
                [Query.equal("email", email)] 
            );

            console.log("Fetched tasks:", show.documents);
            setAllTodo(show.documents); 
        } catch (e) {
            console.error("Error fetching tasks:", e);
        }
    };

    const updateTodo = async (id) => {
        try {
            const updatedTask = await database.updateDocument(
                import.meta.env.VITE_APP_DB_ID,
                import.meta.env.VITE_APP_COLLECTION_ID,
                id,
                {
                    todo: "The task is completed",
                }
            );
            console.log("Task updated:", updatedTask);
            viewTodo(); 
        } catch (e) {
            console.error("Error updating task:", e);
        }

    };
    const deleteTodo = async (id) => {
        try {
            var x = await database.deleteDocument(import.meta.env.VITE_APP_DB_ID,
                import.meta.env.VITE_APP_COLLECTION_ID, id)
            console.log(x);
            viewTodo();
        }
        catch (e) {
            console.log("errors", e);
        }
    };

    return (
        <div className="dashboard-container">
            {email && name ? (
                <>
                    <h1>Welcome, lord {name}</h1>
                    <p>Email: {email}</p>
                    <button onClick={logout}>Logout</button>
                    <br />
                    <br />
                    <input
                        placeholder="Add your tasks"
                        value={todo} 
                        onChange={(e) => setTodo(e.target.value)}
                    />
                    <br />
                    <button onClick={addTodo}>Add</button>
                    {alltodo.length > 0 ? (
                        <div>
                            {alltodo.map((e) => (
                                <div key={e.$id} style={{ marginTop: "10px" }}>
                                    <p>{e.todo}</p>
                                    <button
                                        onClick={() => {
                                            updateTodo(e.$id); 
                                        }}
                                    >
                                        Mark as Completed
                                    </button>
                                    <button onClick={() => {
                                        deleteTodo(e.$id);
                                    }}>delete</button>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <>Loading..</>
                    )}
                </>
            ) : (
                <h1>Loading...........</h1>
            )}
        </div>
    );
}

export default Dashboard;
