import React, { useState } from "react";
import { account } from "../appwrite/config";
import { useNavigate } from "react-router-dom";

const LoginPage = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const login = async () => {
    setLoading(true);
    try {

      const existingSession = await account.get("current");
      if (existingSession) {
        alert("You are already logged in. Redirecting to Dashboard...");
        navigate("/Dashboard");
        return;
      }
    } catch (error) {
      console.log("No active session found. Proceeding to login...");
    }

    try {

      const session = await account.createEmailPasswordSession(email, password);
      console.log("Session successful:", session);
      navigate("/Dashboard");
    } catch (error) {
      console.log("Appwrite error:", error);
      alert("Invalid credentials. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email === "" || password === "") {
      alert("Please enter your credentials.");
      return;
    }
    login();
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <h2>Login</h2>
        {loading ? (
          <div>Loading... Please wait</div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="input-group">
              <label htmlFor="email">Email:</label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                required
              />
            </div>
            <div className="input-group">
              <label htmlFor="password">Password:</label>
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                required
              />
            </div>
            <button type="submit" className="login-button">Login</button>
          </form>
        )}
      </div>
    </div>
  );
};

export default LoginPage;
